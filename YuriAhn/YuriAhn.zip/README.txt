For Effort component: 

-Terrain has bodies of water at lower elevations
-Plants have randomized colors within appropriate color range
-Used 4 different bands of Perlin noise 
-Terrain has 4 different colors according to elevation and terrain type (deep water, shallow water, grassy areas, snowy mountain tips)
-Adjusted height and noise scalars to create the mountainous terrain I wanted to achieve